package com.cs.wwu.csvirtualtour;

public interface OnTaskCompleted {
	void onTaskCompleted(Stop[] s);
	void onTaskCompleted(Map[] m);
}
