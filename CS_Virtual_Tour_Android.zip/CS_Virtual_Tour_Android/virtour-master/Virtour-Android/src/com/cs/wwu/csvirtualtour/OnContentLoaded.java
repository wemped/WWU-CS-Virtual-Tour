package com.cs.wwu.csvirtualtour;

public interface OnContentLoaded {
	
	void onContentLoaded();

}
